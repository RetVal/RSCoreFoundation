//
//  RSRenrenCore.m
//  RSRenrenCore
//
//  Created by closure on 1/3/14.
//  Copyright (c) 2014 closure. All rights reserved.
//

#include "RSRenrenCore.h"
